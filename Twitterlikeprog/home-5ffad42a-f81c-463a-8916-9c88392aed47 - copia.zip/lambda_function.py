import sys
import logging
import pymysql
import json
import base64
from urllib.parse import parse_qs

rds_host = "34.231.179.97"

username = "admin"
password ="password"
dbname = "twitter"


def lambda_handler(event , context):
    print(json.dumps(event));
    
    user="err";
    idMensaje="err";
    
    
    if "isBase64Encoded" in event:
        isEncoded=bool(event["isBase64Encoded"]);
    
        if isEncoded :
            decodedBytes = base64.b64decode(event["body"]);
            decodedStr = decodedBytes.decode("ascii") ;
            print(json.dumps(parse_qs(decodedStr)));
            decodedEvent=json.loads(json.dumps(parse_qs(decodedStr)));
            user=decodedEvent["username"][0];
            idMensaje=decodedEvent["idposts"][0];
            
    else:
        user=event["body"]["username"];
        idMensaje=event["body"]["idposts"];
       
    print(user);
    print(idMensaje);
   
    
    try:
        conn = pymysql.connect(rds_host, user=username, passwd = password, db=dbname, connect_timeout=10, port=3306)
        with conn.cursor() as cur:
            cur.execute("select id from users where username ='" + user +"'");
            var1 = cur.fetchone();
            idUser = str(var1[0]);
            print("el user es: " + idUser)
            print("el post es: " + idMensaje)
            cur.execute("select * from likes where idlikemensaje ='" + idMensaje +"' and iduserlike ='" + idUser +"'");
            conn.commit();
            check = cur.fetchone();
            if check:
                cur.execute("delete from likes where idlikemensaje ='" + idMensaje +"' and iduserlike ='" + idUser +"'");
                conn.commit();

            else:
                cur.execute("insert into likes (idlikemensaje,iduserlike) values ('" + idMensaje +"','" + idUser +"');");
                conn.commit();

            cur.execute("select count(idlike) from likes where idlikemensaje ='" + idMensaje +"'");
            conn.commit();

            counter = cur.fetchone();
            nlikes = str(counter[0]);
            print("-los likes son: " + nlikes)
            return {
                'statusCode': 200,
                'headers': { 'Access-Control-Allow-Origin' : '*' },
                'body' : json.dumps( { 'likes': nlikes } )
            }
            
            conn.commit();
            cur.close();
    except pymysql.MySQLError as e:    
        print (e)
    conn.close();
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps( { 'res': 'OK' } )
    }
