import sys
import logging
import pymysql
import json
import base64
from urllib.parse import parse_qs

rds_host = "34.231.179.97"

username = "admin"
password ="password"
dbname = "twitter"

bucketUrl = "http://nuevbucket.s3.us-east-1.amazonaws.com/"


def lambda_handler(event , context):
    print(json.dumps(event))

    user="err"
    passwd="err"

    if "isBase64Encoded" in event:
        isEncoded=bool(event["isBase64Encoded"])

        if isEncoded:
            decodedBytes = base64.b64decode(event["body"])
            decodedStr = decodedBytes.decode("ascii")
            print(json.dumps(parse_qs(decodedStr)))
            decodedEvent=json.loads(json.dumps(parse_qs(decodedStr)))
            user=decodedEvent["username"][0]
            passwd=decodedEvent["password"][0]

    else:
        user=event["body"]["username"]
        passwd=event["body"]["password"]

    print(user)
    print(passwd)

    try:
        conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE username='" + user + "' AND password='" + passwd + "'")
            conn.commit();
            rows = cur.fetchone()
            cur.close()
            conn.close()

            if rows:
                return {
                    'statusCode': 200,
                    'headers': { 'Access-Control-Allow-Origin' : '' },
                    'body': json.dumps({'exists': True})
                }
            else:
                return {
                    'statusCode': 200,
                    'headers': { 'Access-Control-Allow-Origin' : '' },
                    'body': json.dumps({'exists': False})
                }
    except pymysql.MySQLError as e:
        print (e)
        conn.close()
    
   
    
   
   